<?php
require_once 'config.php';

// Function to get employees by role ID
function getEmployeesByRole($role_id) {
    global $conn;
    
    $sql = "SELECT e.*, er.name as role_name, ed.name as department_name, ep.name as position_name, es.name as section_name 
            FROM employees e 
            LEFT JOIN emp_roles er ON e.role_id = er.id 
            LEFT JOIN emp_department ed ON e.department_id = ed.id 
            LEFT JOIN emp_positions ep ON e.position_id = ep.id 
            LEFT JOIN emp_sections es ON e.section_id = es.id 
            WHERE e.is_inactive = 0 AND e.role_id = ? 
            ORDER BY e.fullname";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $role_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get all employees with role_id = 5 (Staff) - kept for backward compatibility
function getStaffEmployees() {
    return getEmployeesByRole(5);
}

// Function to get all employees
function getAllEmployees() {
    global $conn;
    
    $sql = "SELECT e.*, er.name as role_name, ed.name as department_name, ep.name as position_name, es.name as section_name 
            FROM employees e 
            LEFT JOIN emp_roles er ON e.role_id = er.id 
            LEFT JOIN emp_department ed ON e.department_id = ed.id 
            LEFT JOIN emp_positions ep ON e.position_id = ep.id 
            LEFT JOIN emp_sections es ON e.section_id = es.id 
            WHERE e.is_inactive = 0 
            ORDER BY e.fullname";
    
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get employee by ID
function getEmployeeById($id) {
    global $conn;
    
    $sql = "SELECT e.*, er.name as role_name, ed.name as department_name, ep.name as position_name, es.name as section_name 
            FROM employees e 
            LEFT JOIN emp_roles er ON e.role_id = er.id 
            LEFT JOIN emp_department ed ON e.department_id = ed.id 
            LEFT JOIN emp_positions ep ON e.position_id = ep.id 
            LEFT JOIN emp_sections es ON e.section_id = es.id 
            WHERE e.id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

// Function to get evaluation workflow for a specific employee role
function getEvaluationWorkflowByRole($employee_role_id) {
    // Define workflows based on role
    $workflows = [
        5 => [1, 4, 3, 2], // Staff: HR -> Shift Leader -> Supervisor -> Manager
        4 => [1, 3, 2],    // Shift Leader: HR -> Supervisor -> Manager
        3 => [1, 2]        // Supervisor: HR -> Manager
    ];
    
    return $workflows[$employee_role_id] ?? [1]; // Default to HR only if role not found
}

// Function to create new evaluation with role-specific workflow
function createEvaluationWithRole($employee_id, $employee_role_id, $evaluation_reason, $period_from, $period_to, $additional_fields = []) {
    global $conn;
    
    // Get the first evaluator for this role (always HR = role_id 1)
    $workflow = getEvaluationWorkflowByRole($employee_role_id);
    $first_evaluator_role_id = $workflow[0];
    
    // Build the SQL query dynamically based on additional fields
    $base_sql = "INSERT INTO evaluations (employee_id, evaluation_reason, evaluation_date, period_covered_from, period_covered_to, status, current_evaluator_role_id";
    $values_sql = "VALUES (?, ?, CURDATE(), ?, ?, 'pending', ?";
    $params = [$employee_id, $evaluation_reason, $period_from, $period_to, $first_evaluator_role_id];
    $param_types = "isssi";
    
    // Add additional fields for Staff evaluations
    if (!empty($additional_fields)) {
        foreach ($additional_fields as $field => $value) {
            $base_sql .= ", " . $field;
            $values_sql .= ", ?";
            $params[] = $value;
            $param_types .= "i";
        }
    }
    
    $sql = $base_sql . ") " . $values_sql . ")";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($param_types, ...$params);
    
    if ($stmt->execute()) {
        $evaluation_id = $conn->insert_id;
        
        // Create workflow entries for all evaluators in sequence
        createEvaluationWorkflowByRole($evaluation_id, $employee_role_id);
        
        // Send notification to first evaluator
        notifyNextEvaluator($evaluation_id, $first_evaluator_role_id);
        
        return $evaluation_id;
    }
    
    return false;
}

// Function to create evaluation workflow based on employee role
function createEvaluationWorkflowByRole($evaluation_id, $employee_role_id) {
    global $conn;
    
    $workflow = getEvaluationWorkflowByRole($employee_role_id);
    
    foreach ($workflow as $step_order => $evaluator_role_id) {
        $status = ($step_order == 0) ? 'pending' : 'waiting'; // Only first step is pending (0-indexed)
        $sql = "INSERT INTO evaluation_workflow (evaluation_id, evaluator_role_id, status, step_order) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $actual_step_order = $step_order + 1; // Convert to 1-indexed for database
        $stmt->bind_param("iisi", $evaluation_id, $evaluator_role_id, $status, $actual_step_order);
        $stmt->execute();
    }
}

// Function to create new evaluation with sequential workflow (kept for backward compatibility)
function createEvaluation($employee_id, $evaluation_reason, $period_from, $period_to) {
    // Get employee role to determine workflow
    $employee = getEmployeeById($employee_id);
    if (!$employee) {
        return false;
    }
    
    return createEvaluationWithRole($employee_id, $employee['role_id'], $evaluation_reason, $period_from, $period_to);
}

// Function to create evaluation workflow with sequential steps (kept for backward compatibility)
function createEvaluationWorkflow($evaluation_id) {
    global $conn;
    
    // Get evaluation to determine employee role
    $evaluation = getEvaluationById($evaluation_id);
    if (!$evaluation) {
        return false;
    }
    
    $employee = getEmployeeById($evaluation['employee_id']);
    if (!$employee) {
        return false;
    }
    
    return createEvaluationWorkflowByRole($evaluation_id, $employee['role_id']);
}

// Function to get evaluation by ID (enhanced to include additional fields)
function getEvaluationById($id) {
    global $conn;
    
    $sql = "SELECT ev.*, e.fullname, e.card_no, e.hired_date, e.role_id as employee_role_id,
                   ed.name as department_name, ep.name as position_name, es.name as section_name,
                   er.name as current_evaluator_role_name
            FROM evaluations ev
            JOIN employees e ON ev.employee_id = e.id
            LEFT JOIN emp_department ed ON e.department_id = ed.id 
            LEFT JOIN emp_positions ep ON e.position_id = ep.id 
            LEFT JOIN emp_sections es ON e.section_id = es.id 
            LEFT JOIN emp_roles er ON ev.current_evaluator_role_id = er.id
            WHERE ev.id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

// Function to get evaluations for an employee
function getEmployeeEvaluations($employee_id) {
    global $conn;
    
    $sql = "SELECT ev.*, er.name as current_evaluator_role_name 
            FROM evaluations ev
            LEFT JOIN emp_roles er ON ev.current_evaluator_role_id = er.id
            WHERE ev.employee_id = ? 
            ORDER BY ev.created_date DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get pending evaluations for current evaluator only
function getPendingEvaluationsForEvaluator($role_id, $department_id = null, $user = null) {
    global $conn;
    
    $sql = "SELECT ev.*, e.fullname, e.card_no, ed.name as department_name, ep.name as position_name
            FROM evaluations ev
            JOIN employees e ON ev.employee_id = e.id
            LEFT JOIN emp_department ed ON e.department_id = ed.id 
            LEFT JOIN emp_positions ep ON e.position_id = ep.id 
            LEFT JOIN emp_sections es ON e.section_id = es.id 
            WHERE ev.current_evaluator_role_id = ? AND ev.status = 'pending'";
    
    $params = [$role_id];
    $param_types = "i";
    
    // Apply department filter if specified
    if ($department_id !== null && $department_id !== '') {
        $sql .= " AND e.department_id = ?";
        $params[] = $department_id;
        $param_types .= "i";
    }
    
    // Apply department-based restrictions for non-admin/non-HR users
    if ($user !== null && !in_array($user['role_id'], [0, 1])) {
        // For Shift Leader, Supervisor, Manager - only show evaluations from same department
        if (in_array($user['role_id'], [2, 3, 4])) {
            $sql .= " AND e.department_id = ?";
            $params[] = $user['department_id'];
            $param_types .= "i";
        }
    }
    
    $sql .= " ORDER BY ev.created_date ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($param_types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to check if user can evaluate specific evaluation
function canUserEvaluateThis($evaluation_id, $user_role_id) {
    global $conn;
    
    $sql = "SELECT current_evaluator_role_id FROM evaluations WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $evaluation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $evaluation = $result->fetch_assoc();
    
    return $evaluation && $evaluation['current_evaluator_role_id'] == $user_role_id;
}

function getEvaluationCriteria() {
    global $conn;

    $sql = "SELECT id, criteria_name, criteria_description, order_num 
            FROM evaluation_criteria 
            GROUP BY criteria_name, criteria_description, order_num 
            ORDER BY order_num";
    $result = $conn->query($sql);

    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get criteria permissions based on user role
function getCriteriaPermissions($role_id) {
    // Define criteria permissions based on role
    // HR (role_id = 1): Can edit only Criteria 4, view-only Criteria 1,2,3,5
    // Shift Leader (role_id = 4), Supervisor (role_id = 3), Manager (role_id = 2): Can edit Criteria 1,2,3,5, view-only Criteria 4
    
    $permissions = [];
    
    if ($role_id == 1) { // HR
        $permissions = [
            'editable' => [4], // Can edit Criteria 4 (Attendance and Punctuality)
            'view_only' => [1, 2, 3, 5] // View-only Criteria 1,2,3,5
        ];
    } else if (in_array($role_id, [2, 3, 4])) { // Manager, Supervisor, Shift Leader
        $permissions = [
            'editable' => [1, 2, 3, 5], // Can edit Criteria 1,2,3,5
            'view_only' => [4] // View-only Criteria 4 (Attendance and Punctuality)
        ];
    } else {
        // Default: no permissions
        $permissions = [
            'editable' => [],
            'view_only' => []
        ];
    }
    
    return $permissions;
}

// Function to save evaluation response (enhanced to include recommendation)
function saveEvaluationResponse($evaluation_id, $criteria_id, $evaluator_id, $score, $comments, $recommendation = null) {
    global $conn;
    
    // Check if response already exists
    $sql = "SELECT id FROM evaluation_responses WHERE evaluation_id = ? AND criteria_id = ? AND evaluator_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $evaluation_id, $criteria_id, $evaluator_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update existing response
        $sql = "UPDATE evaluation_responses SET score = ?, comments = ?, recommendation = ?, updated_date = CURRENT_TIMESTAMP 
                WHERE evaluation_id = ? AND criteria_id = ? AND evaluator_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isssii", $score, $comments, $recommendation, $evaluation_id, $criteria_id, $evaluator_id);
    } else {
        // Insert new response
        $sql = "INSERT INTO evaluation_responses (evaluation_id, criteria_id, evaluator_id, score, comments, recommendation) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiiss", $evaluation_id, $criteria_id, $evaluator_id, $score, $comments, $recommendation);
    }
    
    return $stmt->execute();
}

function completeEvaluationStep($evaluation_id, $evaluator_role_id, $evaluator_id) {
    global $conn;
    
    // Update current workflow step to completed
    $sql = "UPDATE evaluation_workflow SET status = 'completed', evaluator_id = ?, completed_date = CURRENT_TIMESTAMP 
            WHERE evaluation_id = ? AND evaluator_role_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $evaluator_id, $evaluation_id, $evaluator_role_id);
    $stmt->execute();
    
    // Get evaluation to determine employee role
    $evaluation = getEvaluationById($evaluation_id);
    if (!$evaluation) {
        return false;
    }
    
    // Get workflow for this employee role
    $workflow = getEvaluationWorkflowByRole($evaluation['employee_role_id']);
    
    // Find current step and get next step
    $current_step_index = array_search($evaluator_role_id, $workflow);
    if ($current_step_index !== false && $current_step_index < count($workflow) - 1) {
        // There is a next step
        $next_evaluator_role_id = $workflow[$current_step_index + 1];
        
        // Update evaluation to next evaluator
        $sql = "UPDATE evaluations SET current_evaluator_role_id = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $next_evaluator_role_id, $evaluation_id);
        $stmt->execute();
        
        // Update next workflow step to pending
        $sql = "UPDATE evaluation_workflow SET status = 'pending' 
                WHERE evaluation_id = ? AND evaluator_role_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $evaluation_id, $next_evaluator_role_id);
        $stmt->execute();
        
        // Send notification to next evaluator
        notifyNextEvaluator($evaluation_id, $next_evaluator_role_id);
        
        return false; // Still pending evaluations
    } else {
        // All evaluations complete, update main evaluation status
        $sql = "UPDATE evaluations SET status = 'completed', current_evaluator_role_id = NULL WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $evaluation_id);
        $stmt->execute();
        
        // Notify staff that evaluation is complete
        notifyEvaluationComplete($evaluation_id);
        
        return true; // Evaluation fully completed
    }
}

// Function to notify next evaluator
function notifyNextEvaluator($evaluation_id, $role_id) {
    global $conn;
    
    // Get evaluators with the specified role
    $sql = "SELECT e.email, e.fullname FROM employees e WHERE e.role_id = ? AND e.is_inactive = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $role_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $evaluators = $result->fetch_all(MYSQLI_ASSOC);
    
    // Get evaluation details
    $evaluation = getEvaluationById($evaluation_id);
    
    foreach ($evaluators as $evaluator) {
        if (!empty($evaluator['email'])) {
            $subject = "Performance Evaluation Pending - " . $evaluation['fullname'];
            $message = "Dear " . $evaluator['fullname'] . ",\n\n";
            $message .= "A performance evaluation for " . $evaluation['fullname'] . " is now pending your review.\n";
            $message .= "Evaluation ID: " . $evaluation_id . "\n";
            $message .= "Employee: " . $evaluation['fullname'] . "\n";
            $message .= "Department: " . $evaluation['department_name'] . "\n";
            $message .= "Position: " . $evaluation['position_name'] . "\n\n";
            $message .= "Please log in to the system to complete your evaluation.\n\n";
            $message .= "Best regards,\nPerformance Evaluation System";
            
            // Use email function if available
            if (function_exists('sendEmail')) {
                sendEmail($evaluator['email'], $subject, $message);
            }
        }
    }
}

// Function to notify staff that evaluation is complete
function notifyEvaluationComplete($evaluation_id) {
    global $conn;
    
    $evaluation = getEvaluationById($evaluation_id);
    $employee = getEmployeeById($evaluation['employee_id']);
    
    if (!empty($employee['email'])) {
        $subject = "Performance Evaluation Completed";
        $message = "Dear " . $employee['fullname'] . ",\n\n";
        $message .= "Your performance evaluation has been completed by all evaluators.\n";
        $message .= "Evaluation ID: " . $evaluation_id . "\n";
        $message .= "Evaluation Date: " . $evaluation['evaluation_date'] . "\n";
        $message .= "Period Covered: " . $evaluation['period_covered_from'] . " to " . $evaluation['period_covered_to'] . "\n\n";
        $message .= "You can now view your evaluation results in the system.\n\n";
        $message .= "Best regards,\nPerformance Evaluation System";
        
        // Use email function if available
        if (function_exists('sendEmail')) {
            sendEmail($employee['email'], $subject, $message);
        }
    }
}

// Function to get evaluation responses (enhanced to include recommendation)
function getEvaluationResponses($evaluation_id) {
    global $conn;
    
    $sql = "SELECT er.*, ec.criteria_name, ec.order_num, e.fullname as evaluator_name, emp_r.name as evaluator_role
            FROM evaluation_responses er
            JOIN evaluation_criteria ec ON er.criteria_id = ec.id
            JOIN employees e ON er.evaluator_id = e.id
            JOIN emp_roles emp_r ON e.role_id = emp_r.id
            WHERE er.evaluation_id = ?
            ORDER BY ec.order_num, emp_r.order_num";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $evaluation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get evaluation summary (enhanced to include recommendation)
function getEvaluationSummary($evaluation_id) {
    global $conn;
    
    $sql = "SELECT ec.criteria_name, ec.order_num, 
                   AVG(er.score) as average_score,
                   GROUP_CONCAT(CONCAT(e.fullname, ': ', er.score) SEPARATOR '; ') as individual_scores,
                   GROUP_CONCAT(CONCAT(e.fullname, ': ', er.comments) SEPARATOR '; ') as all_comments,
                   GROUP_CONCAT(CONCAT(e.fullname, ': ', COALESCE(er.recommendation, 'N/A')) SEPARATOR '; ') as all_recommendations
            FROM evaluation_responses er
            JOIN evaluation_criteria ec ON er.criteria_id = ec.id
            JOIN employees e ON er.evaluator_id = e.id
            JOIN emp_roles emp_r ON e.role_id = emp_r.id
            WHERE er.evaluation_id = ?
            GROUP BY ec.id, ec.criteria_name, ec.order_num
            ORDER BY ec.order_num";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $evaluation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get all departments
function getAllDepartments() {
    global $conn;
    
    $sql = "SELECT * FROM emp_department WHERE is_disabled = 0 ORDER BY name";
    $result = $conn->query($sql);
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get all positions
function getAllPositions() {
    global $conn;
    
    $sql = "SELECT * FROM emp_positions WHERE is_disabled = 0 ORDER BY name";
    $result = $conn->query($sql);
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get all sections
function getAllSections() {
    global $conn;
    
    $sql = "SELECT * FROM emp_sections WHERE is_disabled = 0 ORDER BY name";
    $result = $conn->query($sql);
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get all roles
function getAllRoles() {
    global $conn;
    
    $sql = "SELECT * FROM emp_roles WHERE is_disabled = 0 ORDER BY order_num";
    $result = $conn->query($sql);
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get all evaluations (enhanced to include additional fields)
function getAllEvaluations($department_id = null, $user = null) {
    global $conn;
    
    $sql = "SELECT ev.*, e.fullname, e.card_no, e.hired_date, e.role_id as employee_role_id,
                   ed.name as department_name, ep.name as position_name, es.name as section_name,
                   er.name as current_evaluator_role_name, emp_role.name as employee_role_name
            FROM evaluations ev
            JOIN employees e ON ev.employee_id = e.id
            LEFT JOIN emp_department ed ON e.department_id = ed.id 
            LEFT JOIN emp_positions ep ON e.position_id = ep.id 
            LEFT JOIN emp_sections es ON e.section_id = es.id 
            LEFT JOIN emp_roles er ON ev.current_evaluator_role_id = er.id
            LEFT JOIN emp_roles emp_role ON e.role_id = emp_role.id";
    
    $where_conditions = [];
    $params = [];
    $param_types = "";
    
    // Apply department filter if specified
    if ($department_id !== null && $department_id !== '') {
        $where_conditions[] = "e.department_id = ?";
        $params[] = $department_id;
        $param_types .= "i";
    }
    
    // Apply department-based restrictions for non-admin/non-HR users
    if ($user !== null && !in_array($user['role_id'], [0, 1])) {
        // For Shift Leader, Supervisor, Manager - only show evaluations from same department
        if (in_array($user['role_id'], [2, 3, 4])) {
            $where_conditions[] = "e.department_id = ?";
            $params[] = $user['department_id'];
            $param_types .= "i";
        }
    }
    
    if (!empty($where_conditions)) {
        $sql .= " WHERE " . implode(" AND ", $where_conditions);
    }
    
    $sql .= " ORDER BY ev.created_date DESC";
    
    if (!empty($params)) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($param_types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $result = $conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}

// Function to get completed evaluations by user with optional department filter
function getCompletedEvaluationsByUser($user_id, $department_id = null) {
    global $conn;
    
    $sql = "SELECT ev.*, e.fullname, e.card_no, e.hired_date, e.role_id as employee_role_id,
                   ed.name as department_name, ep.name as position_name, es.name as section_name,
                   er.name as current_evaluator_role_name, emp_role.name as employee_role_name
            FROM evaluations ev
            JOIN employees e ON ev.employee_id = e.id
            LEFT JOIN emp_department ed ON e.department_id = ed.id 
            LEFT JOIN emp_positions ep ON e.position_id = ep.id 
            LEFT JOIN emp_sections es ON e.section_id = es.id 
            LEFT JOIN emp_roles er ON ev.current_evaluator_role_id = er.id
            LEFT JOIN emp_roles emp_role ON e.role_id = emp_role.id
            WHERE ev.status = 'completed' AND EXISTS (
                SELECT 1 FROM evaluation_workflow ew 
                WHERE ew.evaluation_id = ev.id 
                AND ew.evaluator_id = ? 
                AND ew.status = 'completed'
            )";
    
    if ($department_id !== null && $department_id !== '') {
        $sql .= " AND e.department_id = ?";
    }
    
    $sql .= " ORDER BY ev.created_date DESC";
    
    if ($department_id !== null && $department_id !== '') {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $user_id, $department_id);
    } else {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get current evaluation step
function getCurrentEvaluationStep($evaluation_id) {
    global $conn;

    $sql = "SELECT er.name as role_name FROM evaluations ev
            LEFT JOIN emp_roles er ON ev.current_evaluator_role_id = er.id
            WHERE ev.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $evaluation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    return $row && $row["role_name"] ? $row["role_name"] : 'Completed';
}

// Function to get evaluation workflow status
function getEvaluationWorkflowStatus($evaluation_id) {
    global $conn;

    $sql = "
        SELECT 
            er.name AS role_name,
            MAX(ew.status) AS status,
            MAX(ew.completed_date) AS completed_date,
            (
                SELECT e.fullname 
                FROM employees e 
                WHERE e.id = (
                    SELECT ew2.evaluator_id 
                    FROM evaluation_workflow ew2 
                    WHERE ew2.evaluator_role_id = ew.evaluator_role_id 
                      AND ew2.evaluation_id = ew.evaluation_id 
                    LIMIT 1
                )
            ) AS evaluator_name
        FROM evaluation_workflow ew
        JOIN emp_roles er ON ew.evaluator_role_id = er.id
        WHERE ew.evaluation_id = ?
        GROUP BY ew.evaluator_role_id, er.name
        ORDER BY MIN(ew.step_order)
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $evaluation_id);
    $stmt->execute();
    $result = $stmt->get_result();

    return $result->fetch_all(MYSQLI_ASSOC);
}

?>