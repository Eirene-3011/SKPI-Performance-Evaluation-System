<?php
// REMOVED: The session_start() block was here. It's no longer needed as auth.php handles it.

// It's good practice to check for the existence of required files before including them
$required_files = [
    'auth.php',
    'database_functions_enhanced.php',
    'admin_functions.php',
    'email_functions.php'
];

foreach ($required_files as $file) {
    if (!file_exists($file)) {
        // Stop execution with a clear error message if a file is missing
        die("<strong>Critical Error:</strong> Required file not found: <strong>{$file}</strong>. Please check the file path and ensure it is uploaded correctly.");
    }
    require_once $file;
}

// Check if user is logged in and is an admin
requireAdmin();

$user = getCurrentUser();
$success_message = '';
$error_message = '';

// --- Get every reason from the DB ---
$evaluation_reasons = [];
$sql  = "SELECT reason_name FROM evaluation_reasons ORDER BY reason_name";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
$evaluation_reasons = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get available roles for evaluation (Staff, Shift Leader, Supervisor)
$available_roles = [
    ['id' => 5, 'name' => 'Staff'],
    ['id' => 4, 'name' => 'Shift Leader'],
    ['id' => 3, 'name' => 'Supervisor']
];

// Initialize variables
$selected_role_id = null;
$employees = [];

// Handle AJAX request for employee filtering
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_employees' && isset($_GET['role_id'])) {
    $role_id = (int)$_GET['role_id'];
    $employees = getEmployeesByRole($role_id);
    
    header('Content-Type: application/json');
    echo json_encode($employees);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $role_id = (int)$_POST['role_id'];
    $employee_id = (int)$_POST['employee_id'];
    $evaluation_reason = trim($_POST['evaluation_reason']);
if ($evaluation_reason === 'Other') {
    $other_reason = trim($_POST['other_reason'] ?? '');
    if (!empty($other_reason)) {
        $evaluation_reason = $other_reason;
    } else {
        $error_message = "Please specify the reason for evaluation.";
    }
}

    $period_from = $_POST['period_from'];
    $period_to = $_POST['period_to'];
    
    // Additional fields for Staff evaluations only
    $additional_fields = [];
    if ($role_id == 5) { // Staff role
        $additional_fields = [
            'approved_leaves' => (int)($_POST['approved_leaves'] ?? 0),
            'disapproved_leaves' => (int)($_POST['disapproved_leaves'] ?? 0),
            'tardiness' => (int)($_POST['tardiness'] ?? 0),
            'late_undertime' => (int)($_POST['late_undertime'] ?? 0),
            'offense_1st' => (int)($_POST['offense_1st'] ?? 0),
            'offense_2nd' => (int)($_POST['offense_2nd'] ?? 0),
            'offense_3rd' => (int)($_POST['offense_3rd'] ?? 0),
            'offense_4th' => (int)($_POST['offense_4th'] ?? 0),
            'offense_5th' => (int)($_POST['offense_5th'] ?? 0),
            'suspension_days' => (int)($_POST['suspension_days'] ?? 0)
        ];
    }
    
    // Validate inputs
    if (empty($role_id) || empty($employee_id) || empty($evaluation_reason) || empty($period_from) || empty($period_to)) {
        $error_message = "All fields are required.";
    } else if (strtotime($period_from) > strtotime($period_to)) {
        $error_message = "Period From date cannot be later than Period To date.";
    } else {
        // Create evaluation with role-specific workflow
        $evaluation_id = createEvaluationWithRole($employee_id, $role_id, $evaluation_reason, $period_from, $period_to, $additional_fields);
        
        if ($evaluation_id) {
            // Notify first evaluator (HR)
            $notification_sent = notifyHR($evaluation_id);
            if ($notification_sent) {
                $success_message = "Evaluation created successfully! HR has been notified.";
            } else {
                // This error will now be shown if the email function is missing
                $error_message = "Evaluation created, but failed to send notification email. Please check the system's email configuration or the 'email_functions.php' file.";
            }
        } else {
            $error_message = "Error creating evaluation. Please try again.";
        }
    }
    
    // Set selected role for form persistence
    $selected_role_id = $role_id;
    $employees = getEmployeesByRole($role_id);
}

// Function to notify HR
function notifyHR($evaluation_id) {
    // Check if the email function exists before trying to use it
    if (!function_exists('send_email_notification')) {
        // Return false to indicate failure
        return false;
    }

    global $conn;
    
    // Get HR users (role_id = 1)
    $sql = "SELECT * FROM employees WHERE role_id = 1 AND is_inactive = 0";
    $result = $conn->query($sql);
    $hr_users = $result->fetch_all(MYSQLI_ASSOC);
    
    // Get evaluation details
    $evaluation = getEvaluationById($evaluation_id);
    
    // Notify each HR user
    foreach ($hr_users as $hr_user) {
        $subject = "New Evaluation Created - Action Required";
        $message = "Dear " . $hr_user['fullname'] . ",\n\n";
        $message .= "A new evaluation has been created for " . $evaluation['fullname'] . " (" . $evaluation['card_no'] . ").\n";
        $message .= "Evaluation Reason: " . $evaluation['evaluation_reason'] . "\n";
        $message .= "Period Covered: " . date('M d, Y', strtotime($evaluation['period_covered_from'])) . " - " . date('M d, Y', strtotime($evaluation['period_covered_to'])) . "\n\n";
        $message .= "Please log in to the Performance Evaluation System to complete your evaluation.\n\n";
        $message .= "Thank you,\nPerformance Evaluation System";
        
        // Send email notification
        send_email_notification($hr_user['email'] ?? 'hr@example.com', $subject, $message);
    }
    // Return true to indicate success
    return true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Evaluation - Admin - Performance Evaluation System</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .form-control:focus {
            border-color: #e74c3c;
            outline: none;
            box-shadow: 0 0 5px #e74c3c;
        }
        
        select.form-control {
            height: 42px;
        }
        
        .btn-container {
            margin-top: 30px;
            text-align: center;
        }
        
        .staff-only-fields {
            display: none;
            border: 2px solid #e74c3c;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            background-color: #fdf2f2;
        }
        
        .staff-only-fields.show {
            display: block;
        }
        
        .staff-only-fields h3 {
            color: #e74c3c;
            margin-top: 0;
            margin-bottom: 15px;
        }
        
        .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="logo-section">
                    <img src="assets/seiwa.logo.png" alt="Seiwa Kaiun Philippines Inc." class="logo">
                    <div class="company-info">
                        <h1>Performance Evaluation System</h1>
                        <p>Seiwa Kaiun Philippines Inc.</p>
                    </div>
                </div>
                <div class="user-info">
                    <h3><?php echo htmlspecialchars($user['fullname']); ?></h3>
                    <p><strong>ADMIN</strong> - <?php echo htmlspecialchars($user['department_name']); ?></p>
                    <p>Employee ID: <?php echo htmlspecialchars($user['card_no']); ?></p>
                    <button onclick="location.href='admin_dashboard.php'" class="btn btn-secondary">Back to Dashboard</button>
                    <button onclick="location.href='?logout=1'" class="logout-btn">Logout</button>
                </div>
            </div>
        </div>

        <!-- Page Content -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Create New Evaluation</h2>
            </div>
            
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success_message); ?>
                    <br><br>
                    <a href="admin_dashboard.php" class="btn btn-primary">Back to Dashboard</a>
                </div>
            <?php else: ?>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="role_id" class="form-label">Select Role for Evaluation *</label>
                        <select name="role_id" id="role_id" class="form-control" required onchange="loadEmployees()">
                            <option value="">-- Select Role --</option>
                            <?php foreach ($available_roles as $role): ?>
                                <option value="<?php echo $role['id']; ?>" <?php echo ($selected_role_id == $role['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($role['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="employee_id" class="form-label">Select Employee *</label>
                        <select name="employee_id" id="employee_id" class="form-control" required>
                            <option value="">-- Select Employee --</option>
                            <?php foreach ($employees as $employee): ?>
                                <option value="<?php echo $employee['id']; ?>">
                                    <?php echo htmlspecialchars($employee['fullname']); ?> (<?php echo htmlspecialchars($employee['card_no']); ?>) - 
                                    <?php echo htmlspecialchars($employee['position_name']); ?>, 
                                    <?php echo htmlspecialchars($employee['department_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
    <label for="evaluation_reason" class="form-label">Reason for Evaluation *</label>
    <select name="evaluation_reason" id="evaluation_reason" class="form-control" required>
        <option value="">-- Select Reason --</option>
        <?php foreach ($evaluation_reasons as $reason): ?>
            <?php
                $value     = $reason['reason_name'];
                $selected  = (isset($evaluation_reason) && $evaluation_reason === $value) ? 'selected' : '';
            ?>
            <option value="<?php echo htmlspecialchars($value); ?>" <?php echo $selected; ?>>
                <?php echo htmlspecialchars($value); ?>
            </option>
        <?php endforeach; ?>
        <option value="Other" <?php echo (isset($_POST['evaluation_reason']) && $_POST['evaluation_reason'] === 'Other') ? 'selected' : ''; ?>>
            Others, Please specify:
        </option>
    </select>

    <input type="text"
           id="other_reason"
           name="other_reason"
           class="form-control mt-2"
           placeholder="Please specify"
           style="display: <?php echo (isset($_POST['evaluation_reason']) && $_POST['evaluation_reason'] === 'Other') ? 'block' : 'none'; ?>;"
           value="<?php echo isset($_POST['other_reason']) ? htmlspecialchars($_POST['other_reason']) : ''; ?>" />
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const reasonSelect = document.getElementById('evaluation_reason');
    const otherInput = document.getElementById('other_reason');
    document.getElementById('evaluation_reason').addEventListener('change', toggleStaffFields);
    document.getElementById('role_id').addEventListener('change', toggleStaffFields);


    function toggleOtherInput() {
        if (reasonSelect.value === 'Other') {
            otherInput.style.display = 'block';
            otherInput.required = true;
        } else {
            otherInput.style.display = 'none';
            otherInput.required = false;
            otherInput.value = '';
        }
    }

    reasonSelect.addEventListener('change', toggleOtherInput);
    toggleOtherInput(); // Initialize on page load
});
</script>
<div class="form-group">
                        <label for="period_from" class="form-label">Period Covered From *</label>
                        <input type="date" name="period_from" id="period_from" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="period_to" class="form-label">Period Covered To *</label>
                        <input type="date" name="period_to" id="period_to" class="form-control" required>
                    </div>
                    
                    <!-- Additional Fields for Staff Evaluations Only -->
                    <div id="staff-only-fields" class="staff-only-fields">
                        <h3>Additional Information for Staff Evaluation</h3>
                        
                        <h4>Attendance & Punctuality</h4>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="approved_leaves" class="form-label">Number of Approved Leaves</label>
                                <input type="number" name="approved_leaves" id="approved_leaves" class="form-control" min="0" value="0">
                            </div>
                            <div class="form-group">
                                <label for="disapproved_leaves" class="form-label">Number of Disapproved Leaves</label>
                                <input type="number" name="disapproved_leaves" id="disapproved_leaves" class="form-control" min="0" value="0">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="tardiness" class="form-label">Number of Tardiness</label>
                                <input type="number" name="tardiness" id="tardiness" class="form-control" min="0" value="0">
                            </div>
                            <div class="form-group">
                                <label for="late_undertime" class="form-label">Number of Late/Undertime</label>
                                <input type="number" name="late_undertime" id="late_undertime" class="form-control" min="0" value="0">
                            </div>
                        </div>
                        
                        <h4>Number of Violations</h4>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="offense_1st" class="form-label">1st Offense</label>
                                <input type="number" name="offense_1st" id="offense_1st" class="form-control" min="0" value="0">
                            </div>
                            <div class="form-group">
                                <label for="offense_2nd" class="form-label">2nd Offense</label>
                                <input type="number" name="offense_2nd" id="offense_2nd" class="form-control" min="0" value="0">
                            </div>
                            <div class="form-group">
                                <label for="offense_3rd" class="form-label">3rd Offense</label>
                                <input type="number" name="offense_3rd" id="offense_3rd" class="form-control" min="0" value="0">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="offense_4th" class="form-label">4th Offense</label>
                                <input type="number" name="offense_4th" id="offense_4th" class="form-control" min="0" value="0">
                            </div>
                            <div class="form-group">
                                <label for="offense_5th" class="form-label">5th Offense</label>
                                <input type="number" name="offense_5th" id="offense_5th" class="form-control" min="0" value="0">
                            </div>
                        </div>
                        
                        <h4>Suspensions</h4>
                        <div class="form-group">
                            <label for="suspension_days" class="form-label">Number of Suspension Days</label>
                            <input type="number" name="suspension_days" id="suspension_days" class="form-control" min="0" value="0">
                        </div>
                    </div>
                    
                    <div class="btn-container">
                        <button type="submit" class="btn btn-primary">Create Evaluation</button>
                        <a href="admin_dashboard.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Set default dates
        document.addEventListener('DOMContentLoaded', function() {
            // Set default period_from to 1 year ago
            const oneYearAgo = new Date();
            oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
            document.getElementById('period_from').valueAsDate = oneYearAgo;
            
            // Set default period_to to today
            const today = new Date();
            document.getElementById('period_to').valueAsDate = today;
            
            // Show/hide staff-only fields based on initial selection
            toggleStaffFields();
        });
        
        // Function to load employees based on selected role
        function loadEmployees() {
            const roleId = document.getElementById('role_id').value;
            const employeeSelect = document.getElementById('employee_id');
            
            // Clear current options
            employeeSelect.innerHTML = '<option value="">-- Loading... --</option>';
            
            if (roleId) {
                // Make AJAX request to get employees for the selected role
                fetch(`?ajax=get_employees&role_id=${roleId}`)
                    .then(response => response.json())
                    .then(employees => {
                        employeeSelect.innerHTML = '<option value="">-- Select Employee --</option>';
                        employees.forEach(employee => {
                            const option = document.createElement('option');
                            option.value = employee.id;
                            option.textContent = `${employee.fullname} (${employee.card_no}) - ${employee.position_name}, ${employee.department_name}`;
                            employeeSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error loading employees:', error);
                        employeeSelect.innerHTML = '<option value="">-- Error loading employees --</option>';
                    });
            } else {
                employeeSelect.innerHTML = '<option value="">-- Select Employee --</option>';
            }
            
            // Show/hide staff-only fields
            toggleStaffFields();
        }
        
        // Function to show/hide staff-only fields
        function toggleStaffFields() {
    const roleId = document.getElementById('role_id').value;
    const evaluationReason = document.getElementById('evaluation_reason').value;
    const staffFields = document.getElementById('staff-only-fields');

    // Show only if role is Staff and reason is not empty (including "Other")
    if (roleId == '5' && evaluationReason !== '') {
        staffFields.classList.add('show');
    } else {
        staffFields.classList.remove('show');
    }
}
    </script>
    <script>
document.addEventListener('DOMContentLoaded', function () {
    const reasonSelect = document.getElementById('evaluation_reason');
    const otherInput = document.getElementById('other_reason');
    const roleSelect = document.getElementById('role_id');

    function toggleOtherInput() {
        if (reasonSelect.value === 'Other') {
            otherInput.style.display = 'block';
            otherInput.required = true;
        } else {
            otherInput.style.display = 'none';
            otherInput.required = false;
            otherInput.value = '';
        }
    }

    function toggleStaffFields() {
        const roleId = roleSelect.value;
        const evaluationReason = reasonSelect.value;
        const staffFields = document.getElementById('staff-only-fields');

        if (roleId == '5' && evaluationReason !== '') {
            staffFields.classList.add('show');
        } else {
            staffFields.classList.remove('show');
        }
    }

    reasonSelect.addEventListener('change', () => {
        toggleOtherInput();
        toggleStaffFields();
    });

    roleSelect.addEventListener('change', toggleStaffFields);

    toggleOtherInput();       // Initialize visibility
    toggleStaffFields();      // Show/hide staff section on load
});
</script>

</body>
</html>
