<?php
require_once 'auth.php';
require_once 'database_functions_enhanced.php';

requireLogin();

$user = getCurrentUser();

// Handle logout
if (isset($_GET['logout'])) {
    logoutUser();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Performance Evaluation System</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="logo-section">
                    <img src="assets/seiwa.logo.png" alt="Seiwa Kaiun Philippines Inc." class="logo">
                    <div class="company-info">
                        <h1>Performance Evaluation System</h1>
                        <p>Seiwa Kaiun Philippines Inc.</p>
                    </div>
                </div>
                <div class="user-info">
                    <h3><?php echo htmlspecialchars($user['fullname']); ?></h3>
                    <p><?php echo htmlspecialchars($user['role_name']); ?> - <?php echo htmlspecialchars($user['department_name']); ?></p>
                    <p>Employee ID: <?php echo htmlspecialchars($user['card_no']); ?></p>
                    <button onclick="location.href='dashboard.php'" class="btn btn-secondary">Back to Dashboard</button>
                    <button onclick="location.href='?logout=1'" class="logout-btn">Logout</button>
                </div>
            </div>
        </div>

        <!-- Profile Information -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">My Profile</h2>
            </div>
            <div class="profile-details">
                <div class="profile-section">
                    <h3>Personal Information</h3>
                    <div class="profile-grid">
                        <div class="profile-item">
                            <strong>Full Name:</strong>
                            <p><?php echo htmlspecialchars($user['fullname']); ?></p>
                        </div>
                        <div class="profile-item">
                            <strong>Employee ID:</strong>
                            <p><?php echo htmlspecialchars($user['card_no']); ?></p>
                        </div>
                        <div class="profile-item">
                            <strong>Date Hired:</strong>
                            <p><?php echo date('M d, Y', strtotime($user['hired_date'])); ?></p>
                        </div>
                    </div>
                </div>

                <div class="profile-section">
                    <h3>Position Information</h3>
                    <div class="profile-grid">
                        <div class="profile-item">
                            <strong>Role:</strong>
                            <p><?php echo htmlspecialchars($user['role_name']); ?></p>
                        </div>
                        <div class="profile-item">
                            <strong>Department:</strong>
                            <p><?php echo htmlspecialchars($user['department_name']); ?></p>
                        </div>
                        <div class="profile-item">
                            <strong>Position:</strong>
                            <p><?php echo htmlspecialchars($user['position_name']); ?></p>
                        </div>
                        <div class="profile-item">
                            <strong>Section:</strong>
                            <p><?php echo htmlspecialchars($user["section_name"] ?? "N/A"); ?></p>
                        </div>
                    </div>
                </div>

                <div class="profile-section">
                    <h3>Account Information</h3>
                    <div class="profile-grid">
                        <div class="profile-item">
                            <strong>Password:</strong>
                            <p>********</p>
                        </div>
                        <div class="profile-item">
                            <strong>Last Login:</strong>
                            <p id="last-login"></p>
                            </div>

                            <script>
                            function updateDateTime() {
                                const now = new Date();

                                // Format date like: Apr 26, 2025 14:35:45
                                const options = { month: 'short', day: '2-digit', year: 'numeric' };
                                const dateStr = now.toLocaleDateString('en-US', options);
                                const timeStr = now.toLocaleTimeString('en-US', { hour12: false });

                                document.getElementById('last-login').textContent = `${dateStr} ${timeStr}`;
                            }

                            updateDateTime();            // Initial call
                            setInterval(updateDateTime, 1000); // Update every second
                            </script>
                    </div>
                </div>
            </div>
        </div>

        <!-- Back Button -->
        <div style="text-align: center; margin-top: 20px;">
            <a href="dashboard.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <style>
        .profile-details {
            padding: 20px;
        }
        .profile-section {
            margin-bottom: 30px;
        }
        .profile-section h3 {
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 10px;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        .profile-item strong {
            display: block;
            margin-bottom: 5px;
            color: #7f8c8d;
        }
        .profile-item p {
            font-size: 16px;
            margin: 0;
        }
    </style>
</body>
</html>

